<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Bike extends Model
{


    public $table = "bikes";
    /**
     * Get the user that owns the bike.
     */
    public function user()
    {
        return $this->belongsTo('App\User');
    }
}
