</<!DOCTYPE html>
<html>
<head>
   
</head>
<style>
 
 
</style>
<body>

<h1> One to One relationship In Laravel </h1>

<h2>

<p> Names from Users Table </p>

<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li> 
    
    <?php echo e($user->name); ?>  
 
</li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<p> Bike Names from Bike Table </p>

<?php $__currentLoopData = $allbikes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $allbike): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li> 
    
    <?php echo e($allbike->bike_name); ?>  
 
</li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<p> User_1 (<?php echo e($user_1_name->name); ?>) has <?php echo e($user_1_bike->bike_name); ?> </p>

<p> User_3 (<?php echo e($user_2_name->name); ?>) has <?php echo e($user_3_bike->bike_name); ?> </p>


</body>
</html><?php /**PATH /Users/hardikparsania_mac/Desktop/web_demonuts/laraOnetoOne/laraonetoone/resources/views/index.blade.php ENDPATH**/ ?>